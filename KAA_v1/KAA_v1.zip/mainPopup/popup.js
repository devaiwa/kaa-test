// Below is what we'll log to the console.

console.log("Hello, World! - from popup.js");
