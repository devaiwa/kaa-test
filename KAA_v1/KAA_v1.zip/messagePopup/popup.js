// The user clicked our button, get the active tab in the current window using
// the tabs API.
let tabs = await messenger.tabs.query({ active: true, currentWindow: true });

// Get the message currently displayed in the active tab, using the
// messageDisplay API. Note: This needs the messagesRead permission.
// The returned message is a MessageHeader object with the most relevant
// information.
let message = await messenger.messageDisplay.getDisplayedMessages(tabs[0].id);

// Update the HTML fields with the message subject and sender.
document.getElementById("subject").textContent = message.messages[0].subject;
document.getElementById("from").textContent = message.messages[0].author;

// Request the full message to access its full set of headers.
let full = await messenger.messages.getFull(message.messages[0].id);
console.log("Full Message: ", full);
document.getElementById("received").textContent = full.headers.received[0];
